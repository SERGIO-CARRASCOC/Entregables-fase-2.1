document.addEventListener('DOMContentLoaded', () => {
    const botonVerProbabilidad = document.getElementById('verProbabilidad');
    const selectPeriodo = document.getElementById('periodo');

    botonVerProbabilidad.addEventListener('click', () => {
        const periodoSeleccionado = selectPeriodo.value;
        let url;

        // Establecer la URL según el periodo seleccionado
        switch (periodoSeleccionado) {
            case 'mes':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74#scrollTo=a0dMsnG9cHwC'; // URL para "Próximo mes"
                break;
            case 'semestre':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74'; // URL para "Próximo semestre"
                break;
            case 'año':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74'; // URL para "Próximo año"
                break;
            default:
                alert('Periodo no válido');
                return;
        }

        // Redirigir a la URL correspondiente en una nueva pestaña
        window.open(url, '_blank');
    });
});
