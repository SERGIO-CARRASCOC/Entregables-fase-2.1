let ventasDelDia = Array(30).fill(0);  // Un arreglo para guardar las ventas de los 30 días
let ventasDelMes = 0;  // Acumulador para las ventas del mes
let chartType = 'bar';
let salesChart;

// Registrar venta
function registrarVenta() {
    const venta = document.getElementById('venta-dia').value;
    const dia = document.getElementById('dia-select').value - 1;  // El valor del día seleccionado (restamos 1 para acceder al índice correcto)

    if (venta && venta > 0) {
        ventasDelDia[dia] += parseFloat(venta);
        ventasDelMes += parseFloat(venta);
        actualizarDashboard();
        actualizarGrafico();
    } else {
        alert("Por favor ingresa un valor válido para la venta.");
    }
}

// Eliminar venta
function eliminarVenta() {
    const dia = document.getElementById('dia-select').value - 1;

    const ventaEliminada = ventasDelDia[dia];
    if (ventaEliminada > 0) {
        ventasDelDia[dia] = 0;
        ventasDelMes -= ventaEliminada;
        actualizarDashboard();
        actualizarGrafico();
    } else {
        alert("No hay ventas registradas en este día para eliminar.");
    }
}

// Actualizar el Dashboard
function actualizarDashboard() {
    const totalVentas = ventasDelDia.reduce((acc, val) => acc + val, 0);
    document.getElementById('total-ventas').textContent = `$${totalVentas}`;
    document.getElementById('ventas-mes').textContent = `$${ventasDelMes}`;
    document.getElementById('ventas-dia').textContent = `$${ventasDelDia.reduce((acc, val) => acc + val, 0)}`;
}

// Actualizar el gráfico
function actualizarGrafico() {
    const ctx = document.getElementById('sales-chart').getContext('2d');
    if (salesChart) {
        salesChart.destroy();
    }

    salesChart = new Chart(ctx, {
        type: chartType,
        data: {
            labels: Array.from({ length: 30 }, (_, i) => `Día ${i + 1}`),
            datasets: [{
                label: 'Ventas del Día',
                data: ventasDelDia,
                backgroundColor: '#4CAF50',
                borderColor: '#388E3C',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Función para generar gráficos
function generateCharts() {
    const ctx = document.getElementById('sales-chart').getContext('2d');
    if (salesChart) {
        salesChart.destroy();
    }

    salesChart = new Chart(ctx, {
        type: chartType,
        data: {
            labels: Array.from({ length: 30 }, (_, i) => `Día ${i + 1}`),
            datasets: [{
                label: 'Ventas del Día',
                data: ventasDelDia,
                backgroundColor: '#4CAF50',
                borderColor: '#388E3C',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Cambiar tipo de gráfico
function changeChartType() {
    chartType = chartType === 'bar' ? 'pie' : 'bar';
    generateCharts();
}

// Inicializar los gráficos cuando se cargue la página
document.addEventListener('DOMContentLoaded', generateCharts);
