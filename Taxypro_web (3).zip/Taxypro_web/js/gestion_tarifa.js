document.getElementById('guardarTarifa').addEventListener('click', function() {
    const tipoTarifa = document.getElementById('tipoTarifa').value;
    const valor = document.getElementById('valor').value;

    if (valor === "") {
        alert("Por favor, ingresa un valor.");
        return;
    }

    const tarifa = {
        tipo: tipoTarifa,
        valor: valor
    };

    agregarTarifa(tarifa);
    guardarTarifasEnLocalStorage(); // Guardamos las tarifas en LocalStorage
});

function agregarTarifa(tarifa) {
    const lista = document.getElementById('listaTarifas');
    const listaItem = document.createElement('li');
    listaItem.textContent = `Tipo de tarifa: ${tarifa.tipo}, Valor: $${tarifa.valor}`;

    // Crear botón de eliminar
    const eliminarBtn = document.createElement('button');
    eliminarBtn.textContent = "Eliminar";
    eliminarBtn.onclick = function() {
        lista.removeChild(listaItem);
        guardarTarifasEnLocalStorage(); // Volver a guardar las tarifas después de eliminar
    };

    listaItem.appendChild(eliminarBtn);
    lista.appendChild(listaItem);
}

function guardarTarifasEnLocalStorage() {
    const tarifas = [];
    const listaItems = document.querySelectorAll('#listaTarifas li');
    
    listaItems.forEach(item => {
        const tarifaTexto = item.textContent.replace('Eliminar', '').trim();
        const [tipo, valor] = tarifaTexto.split(', Valor: ');
        tarifas.push({
            tipo: tipo.replace('Tipo de tarifa: ', ''),
            valor: valor.replace('$', '')
        });
    });

    localStorage.setItem('tarifas', JSON.stringify(tarifas)); // Guardamos las tarifas en LocalStorage
}

function cargarTarifasDesdeLocalStorage() {
    const tarifas = JSON.parse(localStorage.getItem('tarifas'));
    if (tarifas) {
        tarifas.forEach(tarifa => {
            agregarTarifa(tarifa);
        });
    }
}

// Cargar las tarifas guardadas al cargar la página
window.onload = cargarTarifasDesdeLocalStorage;
