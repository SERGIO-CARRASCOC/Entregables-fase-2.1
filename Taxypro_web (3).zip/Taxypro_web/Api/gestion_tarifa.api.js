// api/gestion_tarifa.api.js

const baseUrl = 'http://localhost:3000/api/tarifas';  // Cambia esta URL según tu configuración de NestJS

// Función para obtener todas las tarifas
export const obtenerTarifas = async () => {
  try {
    const response = await fetch(`${baseUrl}`);
    if (response.ok) {
      const tarifas = await response.json();
      return tarifas;
    } else {
      throw new Error('Error al obtener las tarifas');
    }
  } catch (error) {
    console.error('Error en la API:', error);
    return [];
  }
};

// Función para agregar una nueva tarifa
export const agregarTarifa = async (tarifa) => {
  try {
    const response = await fetch(`${baseUrl}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(tarifa),
    });
    if (response.ok) {
      const nuevaTarifa = await response.json();
      return nuevaTarifa;
    } else {
      throw new Error('Error al agregar la tarifa');
    }
  } catch (error) {
    console.error('Error en la API:', error);
  }
};
