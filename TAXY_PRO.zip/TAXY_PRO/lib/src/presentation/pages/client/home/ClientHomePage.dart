import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/main.dart';
import 'package:taxy_pro/src/presentation/pages/client/home/bloc/ClientHomeEvent.dart';
import 'package:taxy_pro/src/presentation/pages/client/home/bloc/ClientHomeBloc.dart';
import 'package:taxy_pro/src/presentation/pages/client/home/bloc/ClientHomeState.dart';
import 'package:taxy_pro/src/presentation/pages/client/mapSeeker/ClientMapSeekerPage.dart';
import 'package:taxy_pro/src/presentation/pages/profile/info/ProfileInfoPage.dart';

class ClientHomePage extends StatefulWidget {
  const ClientHomePage({super.key});

  @override
  State<ClientHomePage> createState() => _ClientHomePageState();
}

class _ClientHomePageState extends State<ClientHomePage> {
  List<Widget> pageList = <Widget>[
    ClientMapSeekerPage(),
    ProfileInfoPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu de opciones'),
      ), // AppBar
      body: BlocBuilder<ClientHomeBloc, ClientHomeState>(
        builder: (context, state) {
          return pageList[state.pageIndex];
        },
      ), // Center
      drawer: BlocBuilder<ClientHomeBloc, ClientHomeState>(
        builder: (context, state) {
          return Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                DrawerHeader(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [Colors.grey, Colors.black],
                    ),
                  ), // BoxDecoration
                  child: Text(
                    'Menu del cliente',
                    style: TextStyle(
                      color: Colors.white,
                    ), // TextStyle
                  ), // Text
                ),
                ListTile(
                    title: Text('Mapa De Busqueda'),
                    selected: state.pageIndex == 0,
                    onTap: () {
                      context
                          .read<ClientHomeBloc>()
                          .add(ChangeDrawerPage(pageIndex: 0));
                      Navigator.pop(context);
                    }),
                ListTile(
                    title: Text('Perfil del usuario'),
                    selected: state.pageIndex == 1,
                    onTap: () {
                      context
                          .read<ClientHomeBloc>()
                          .add(ChangeDrawerPage(pageIndex: 0));
                      Navigator.pop(context);
                    }),
                ListTile(
                  title: Text('Cerrar sesión'),
                  onTap: () {
                    context.read<ClientHomeBloc>().add(Logout());
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => MyApp()),
                      (route) => false,
                    );
                  },
                )

                // DrawerHeader
              ], // children
            ), // ListView
          );
        },
      ), // Drawer
    ); // Scaffold
  }
}
