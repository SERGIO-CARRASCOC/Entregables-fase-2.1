import 'package:flutter/material.dart';

class DefaultTextField extends StatelessWidget {
  final String text;
  final Function(String text) onChanged;
  final IconData icon;
  final EdgeInsetsGeometry margin;
  final String? Function(String?)? validator;
  final Color backgroundColor;

  DefaultTextField({
    required this.text,
    required this.icon,
    required this.onChanged,
    this.margin = const EdgeInsets.only(top: 20, left: 20, right: 20),
    this.validator,
    this.backgroundColor = Colors.black,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin, // Margen configurable
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(15),
          bottomRight: Radius.circular(15),
        ),
      ),
      child: TextFormField(
        onChanged: onChanged, // Notificar cambios al texto
        validator: validator, // Validación del texto
        decoration: InputDecoration(
          labelText: text,
          labelStyle:
              const TextStyle(fontSize: 14), // Ajuste del estilo del label
          prefixIcon: Icon(icon), // Ícono antes del texto
          border: OutlineInputBorder(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15),
              bottomRight: Radius.circular(15),
            ),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15),
              bottomRight: Radius.circular(15),
            ),
            borderSide: BorderSide(color: Theme.of(context).primaryColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(15),
              bottomRight: Radius.circular(15),
            ),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          filled: true,
          fillColor: backgroundColor,
        ),
        style: const TextStyle(fontSize: 16), // Ajuste del texto del input
      ),
    );
  }
}
