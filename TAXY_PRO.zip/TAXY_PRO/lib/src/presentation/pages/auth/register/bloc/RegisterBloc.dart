import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/domain/useCases/auth/AuthUseCase.dart';
import 'package:taxy_pro/src/domain/utils/Resource.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterState.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  final AuthUseCases authUseCases;
  final formKey = GlobalKey<FormState>();

  RegisterBloc(this.authUseCases) : super(RegisterState()) {
    // Inicialización del formulario
    on<RegisterInitEvent>((event, emit) {
      emit(state.copyWith(formKey: formKey));
    });

    // Guardar la sesión del usuario
    on<SaveUserSession>((event, emit) async {
      await authUseCases.saveUserSession.run(event.authResponse);
    });

    // Validación de Nombre
    on<NameChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
            value: event.name.value,
            error: event.name.value.isEmpty ? 'Ingresa el nombre' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    // Validación de Apellido
    on<LastnameChanged>((event, emit) {
      emit(
        state.copyWith(
          lastname: BlocformItem(
            value: event.lastname.value,
            error: event.lastname.value.isEmpty ? 'Ingresa el apellido' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    // Validación de Teléfono
    on<PhoneChanged>((event, emit) {
      emit(
        state.copyWith(
          phone: BlocformItem(
            value: event.phone.value,
            error: event.phone.value.isEmpty ? 'Ingresa el teléfono' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    // Validación de Contraseña
    on<PasswordChanged>((event, emit) {
      emit(
        state.copyWith(
          password: BlocformItem(
            value: event.password.value,
            error: event.password.value.isEmpty
                ? 'Ingresa la contraseña'
                : event.password.value.length < 6
                    ? 'La contraseña debe tener al menos 6 caracteres'
                    : null,
          ),
          formKey: formKey,
        ),
      );
    });

    // Validación de Confirmación de Contraseña
    on<ConfirmPasswordChanged>((event, emit) {
      emit(
        state.copyWith(
          confirmPassword: BlocformItem(
            value: event.confermpassword.value,
            error: event.confermpassword.value.isEmpty
                ? 'Confirma la contraseña'
                : event.confermpassword.value.length < 6
                    ? 'La contraseña debe tener al menos 6 caracteres'
                    : event.confermpassword.value != state.password.value
                        ? 'Las contraseñas no coinciden'
                        : null,
          ),
          formKey: formKey,
        ),
      );
    });

    // Enviar el formulario
    on<FormSubmit>((event, emit) async {
      // Imprimir datos para depuración
      print('name: ${state.name.value}');
      print('lastname: ${state.lastname.value}');
      print('email: ${state.email.value}');
      print('phone: ${state.phone.value}');
      print('password: ${state.password.value}');
      print('confirmPassword: ${state.confirmPassword.value}');

      // Indicar estado de carga
      emit(state.copyWith(response: Loading(), formKey: formKey));

      // Llamar al caso de uso de registro
      Resource response = await authUseCases.register.run(state.toUser());

      // Emitir el resultado del registro
      emit(state.copyWith(response: response, formKey: formKey));
    });

    // Reiniciar el formulario
    on<FormReset>((event, emit) {
      state.formKey?.currentState?.reset();
    });
  }
}
