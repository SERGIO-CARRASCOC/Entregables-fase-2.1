import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:taxy_pro/src/domain/models/User.dart';
import 'package:taxy_pro/src/domain/utils/Resource.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class RegisterState extends Equatable {
  final BlocformItem name;
  final BlocformItem lastname;
  final BlocformItem email;
  final BlocformItem phone;
  final BlocformItem password;
  final BlocformItem confirmPassword;
  final GlobalKey<FormState>? formKey;
  final Resource? response;

  const RegisterState(
      {this.name = const BlocformItem(error: 'Ingresa el nombre'),
      this.lastname = const BlocformItem(error: 'Ingresa el apellido'),
      this.email = const BlocformItem(error: 'Ingresa el email'),
      this.phone = const BlocformItem(error: 'Ingresa el telefono'),
      this.password = const BlocformItem(error: 'Ingresa el password'),
      this.confirmPassword =
          const BlocformItem(error: 'Confirma la contraseña'),
      this.formKey,
      this.response});

  toUser() => User(
      name: name.value,
      lastname: lastname.value,
      email: email.value,
      phone: phone.value,
      password: password.value);

  RegisterState copyWith(
      {BlocformItem? name,
      BlocformItem? lastname,
      BlocformItem? email,
      BlocformItem? phone,
      BlocformItem? password,
      BlocformItem? confirmPassword,
      GlobalKey<FormState>? formKey,
      Resource? response}) {
    return RegisterState(
        name: name ?? this.name,
        lastname: lastname ?? this.lastname,
        email: email ?? this.email,
        phone: phone ?? this.phone,
        password: password ?? this.password,
        confirmPassword: confirmPassword ?? this.confirmPassword,
        formKey: formKey,
        response: response);
  }

  @override
  List<Object?> get props =>
      [name, lastname, email, phone, password, confirmPassword, response];
}
