import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:taxy_pro/src/domain/utils/Resource.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class LoginState extends Equatable {
  final BlocformItem email;
  final BlocformItem password;
  final Resource? response;
  final GlobalKey<FormState>? formKey;

  const LoginState(
      {this.email = const BlocformItem(error: 'Ingresa un Email'),
      this.password = const BlocformItem(error: 'Ingresa tu contraseña'),
      this.formKey,
      this.response});

  LoginState copyWith({
    BlocformItem? email,
    BlocformItem? password,
    Resource? response,
    GlobalKey<FormState>? formKey,
  }) {
    return LoginState(
      email: email ?? this.email,
      password: password ?? this.password,
      response: response,
      formKey: formKey ?? this.formKey,
    );
  }

  @override
  List<Object?> get props => [email, password, response];
}
