import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/domain/models/AuthResponse.dart';
import 'package:taxy_pro/src/domain/useCases/auth/AuthUseCase.dart';
import 'package:taxy_pro/src/domain/utils/Resource.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginState.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  AuthUseCases authUsecase;
  final formKey = GlobalKey<FormState>();

  LoginBloc(this.authUsecase) : super(LoginState()) {
    on<LoginInitEvent>((event, emit) async {
      AuthResponse? authResponse = await authUsecase.getUserSession.run();
      print('Auth Response Session: ${authResponse?.toJson()}');
      emit(state.copyWith(formKey: formKey));
      if (authResponse != null) {
        emit(state.copyWith(response: Success(authResponse), formKey: formKey));
      }
    });

    on<SaveUserSession>((event, emit) async {
      await authUsecase.saveUserSession.run(event.authResponse);
    });

    on<EmailChanged>((event, emit) {
      emit(
        state.copyWith(
            email: BlocformItem(
                value: event.email.value,
                error: event.email.value.isEmpty ? 'Ingresa tu Email' : null),
            formKey: formKey),
      );
    });

    on<PasswordChanged>((event, emit) {
      emit(state.copyWith(
          password: BlocformItem(
              value: event.password.value,
              error: event.password.value.isEmpty
                  ? 'Ingresa tu contraseña'
                  : event.password.value.length < 6
                      ? 'Miimo 6 caracteres '
                      : null),
          formKey: formKey));
    });

    on<FormSubmit>((event, emit) async {
      print('Email: ${state.email.value}');
      print('Password: ${state.password.value}');
      emit(state.copyWith(response: Loading(), formKey: formKey));
      Resource resource =
          await authUsecase.login.run(state.email.value, state.password.value);
      emit(state.copyWith(response: resource, formKey: formKey));
    });
  }
}
