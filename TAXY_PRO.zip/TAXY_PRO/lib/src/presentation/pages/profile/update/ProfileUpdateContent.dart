import 'package:flutter/material.dart';
import 'package:taxy_pro/src/presentation/pages/auth/witgets/DefaultTextField.dart';

class ProfileUpdateContent extends StatelessWidget {
  const ProfileUpdateContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            // Encabezado del perfil
            _headerProfile(context),
            const Spacer(),
            // Botón para actualizar usuario
            _actionProfile(
              'Actualizar Usuario',
              Icons.update,
              onTap: () {
                _logout(context);
              },
            ),
            const SizedBox(height: 35),
          ],
        ),
        // Tarjeta con información del usuario
        _cardUserInfo(context),
      ],
    );
  }

  // Widget para mostrar la tarjeta con la información del usuario
  Widget _cardUserInfo(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, top: 120),
      width: MediaQuery.of(context).size.width,
      height: 400, // Ajusté el alto para acomodar los campos de texto
      child: Card(
        color: Colors.white,
        child: Column(
          children: [
            // Imagen del usuario
            Container(
              width: 115,
              margin: const EdgeInsets.only(top: 15, bottom: 15),
              child: AspectRatio(
                aspectRatio: 1,
                child: ClipOval(
                  child: FadeInImage.assetNetwork(
                    placeholder: 'assets/img/user_image.png',
                    image:
                        'https://tse4.mm.bing.net/th?id=OIP.IGNf7GuQaCqz_RPq5wCkPgHaLH&pid=Api&P=0&h=180',
                    fit: BoxFit.cover,
                    fadeInDuration: const Duration(seconds: 1),
                  ),
                ),
              ),
            ),
            // Campos de texto para información del usuario
            DefaultTextField(
              text: 'Nombre',
              icon: Icons.person,
              onChanged: (text) {
                print("Nombre actualizado: $text");
              },
            ),
            const SizedBox(height: 10),
            DefaultTextField(
              text: 'Apellido',
              icon: Icons.person_outline,
              onChanged: (text) {
                print("Apellido actualizado: $text");
              },
            ),
            const SizedBox(height: 10),
            DefaultTextField(
              text: 'Teléfono',
              icon: Icons.phone,
              onChanged: (text) {
                print("Teléfono actualizado: $text");
              },
            ),
          ],
        ),
      ),
    );
  }

  // Widget para las opciones del perfil
  Widget _actionProfile(String option, IconData icon, {VoidCallback? onTap}) {
    return Container(
      margin: const EdgeInsets.only(left: 35, right: 20, top: 15),
      child: ListTile(
        title: Text(
          option,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color.fromARGB(255, 19, 58, 213),
                Color.fromARGB(255, 65, 173, 255),
              ],
            ),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 24,
          ),
        ),
        onTap: onTap,
      ),
    );
  }

  // Widget para el encabezado del perfil
  Widget _headerProfile(BuildContext context) {
    return Container(
      alignment: Alignment.topCenter,
      padding: const EdgeInsets.only(top: 40),
      height: MediaQuery.of(context).size.height * 0.35,
      width: MediaQuery.of(context).size.width,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.grey, Colors.black],
        ),
      ),
      child: const Text(
        'Perfil de Usuario',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
    );
  }

  // Función para manejar el cierre de sesión
  void _logout(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Cerrar Sesión"),
        content: const Text("¿Estás seguro de que deseas cerrar sesión?"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Cierra el diálogo
            },
            child: const Text("Cancelar"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Cierra el diálogo
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: const Text("Cerrar Sesión"),
          ),
        ],
      ),
    );
  }
}
