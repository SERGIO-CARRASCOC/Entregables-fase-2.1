import 'package:flutter/material.dart';
import 'package:taxy_pro/src/domain/models/User.dart';

class ProfileInfoContent extends StatelessWidget {
  final User? user;

  ProfileInfoContent(this.user);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            // Encabezado del perfil
            _headerProfile(context),
            const Spacer(),
            // Botón para editar perfil
            _actionProfile('Editar Perfil', Icons.edit, () {
              Navigator.pushNamed(context, 'profile/update');
            }),
            // Botón para cerrar sesión
            _actionProfile('Cerrar Sesión', Icons.settings_power, () {}),
            const SizedBox(height: 35),
          ],
        ),
        // Tarjeta con información del usuario
        _cardUserInfo(context),
      ],
    );
  }

  // Tarjeta con información del usuario
  Widget _cardUserInfo(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, top: 120),
      width: MediaQuery.of(context).size.width,
      height: 250,
      child: Card(
        color: Colors.white,
        child: Column(
          children: [
            // Imagen del usuario
            Container(
              width: 115,
              margin: const EdgeInsets.only(top: 15, bottom: 15),
              child: AspectRatio(
                aspectRatio: 1,
                child: ClipOval(
                  child: FadeInImage.assetNetwork(
                    placeholder: 'assets/img/user_image.png',
                    image:
                        'https://tse4.mm.bing.net/th?id=OIP.IGNf7GuQaCqz_RPq5wCkPgHaLH&pid=Api&P=0&h=180',
                    fit: BoxFit.cover,
                    fadeInDuration: const Duration(seconds: 1),
                  ),
                ),
              ),
            ),
            // Información del usuario
            Text(
              '${user?.name ?? ''} ${user?.lastname ?? ''}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            Text(
              user?.email ?? '',
              style: const TextStyle(color: Colors.black),
            ),
            Text(
              user?.phone ?? '',
              style: const TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }

  // Botones para editar y cerrar sesión
  Widget _actionProfile(String option, IconData icon, Function() function) {
    return GestureDetector(
      onTap: () {
        function();
      },
      child: Container(
        margin: const EdgeInsets.only(left: 35, right: 20, top: 15),
        child: ListTile(
          title: Text(
            option,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
                  Color.fromARGB(255, 19, 58, 213),
                  Color.fromARGB(255, 65, 173, 255),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
          ),
        ),
      ),
    );
  }

  // Encabezado del perfil
  Widget _headerProfile(BuildContext context) {
    return Container(
      alignment: Alignment.topCenter,
      padding: const EdgeInsets.only(top: 40),
      height: MediaQuery.of(context).size.height * 0.35,
      width: MediaQuery.of(context).size.width,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.grey, Colors.black],
        ),
      ),
      child: const Text(
        'Perfil de Usuario',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
    );
  }

  // Función para cerrar sesión
  void _logout(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Cerrar Sesión"),
        content: const Text("¿Estás seguro de que deseas cerrar sesión?"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text("Cancelar"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/login');
            },
            child: const Text("Cerrar Sesión"),
          ),
        ],
      ),
    );
  }
}
