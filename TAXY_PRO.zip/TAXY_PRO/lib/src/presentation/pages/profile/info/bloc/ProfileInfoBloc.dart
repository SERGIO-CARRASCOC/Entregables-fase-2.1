import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/domain/models/AuthResponse.dart';
import 'package:taxy_pro/src/domain/useCases/auth/AuthUseCase.dart';
import 'package:taxy_pro/src/presentation/pages/profile/info/bloc/ProfeleInfoEvent.dart';
import 'package:taxy_pro/src/presentation/pages/profile/info/bloc/ProfileInfoState.dart';

class ProfileInfoBloc extends Bloc<ProfeleInfoEvent, ProfileInfoState> {
  final AuthUseCases authUseCases;

  ProfileInfoBloc(this.authUseCases) : super(ProfileInfoState()) {
    on<GetUserInfo>((event, emit) async {
      AuthResponse authResponse = await authUseCases.getUserSession.run();
      emit(
        state.copyWith(
          user: authResponse.user,
        ),
      );
    });
  }
}
