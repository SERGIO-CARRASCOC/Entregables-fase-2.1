abstract class ProfeleInfoEvent {}

class GetUserInfo extends ProfeleInfoEvent {}
