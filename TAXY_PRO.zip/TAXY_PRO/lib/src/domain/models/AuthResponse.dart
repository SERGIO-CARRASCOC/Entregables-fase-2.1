import 'dart:convert';

import 'package:taxy_pro/src/domain/models/User.dart';

AuthResponse authResponseFromJson(String str) =>
    AuthResponse.fromJson(json.decode(str));

String authResponseToJson(AuthResponse data) => json.encode(data.toJson());

class AuthResponse {
  User user;
  String token;

  AuthResponse({
    required this.user,
    required this.token,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) => AuthResponse(
        user: User.fromJson(json["User"]),
        token: json["token"],
      );

  Map<String, dynamic> toJson() => {
        "User": user.toJson(),
        "token": token,
      };
}
