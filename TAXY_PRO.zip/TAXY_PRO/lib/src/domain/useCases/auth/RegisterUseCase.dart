import 'package:taxy_pro/src/domain/models/User.dart';
import 'package:taxy_pro/src/domain/repository/AuthRepository.dart';

class RegisterUseCase {
  AuthRepository authRepository;
  RegisterUseCase(this.authRepository);

  run(User user) => authRepository.register(user);
}
