import 'package:injectable/injectable.dart';
import 'package:taxy_pro/src/data/dataSource/local/SharefPref.dart';
import 'package:taxy_pro/src/data/dataSource/remote/services/AuthService.dart';
import 'package:taxy_pro/src/data/repositiry/AuthRepositoryImpl.dart';
import 'package:taxy_pro/src/domain/repository/AuthRepository.dart';
import 'package:taxy_pro/src/domain/useCases/auth/AuthUseCase.dart';
import 'package:taxy_pro/src/domain/useCases/auth/GetUserSessionUseCase.dart';
import 'package:taxy_pro/src/domain/useCases/auth/LoginUseCase.dart';
import 'package:taxy_pro/src/domain/useCases/auth/LogoutUseCase.dart';
import 'package:taxy_pro/src/domain/useCases/auth/RegisterUseCase.dart';
import 'package:taxy_pro/src/domain/useCases/auth/SaveUserSessionUseCase.dart';

@module
abstract class AppModule {
  @injectable
  SharePref get sharePref => SharePref();

  @injectable
  AuthService get authService => AuthService();

  @injectable
  AuthRepository get authRepository =>
      AuthRepositoryImpl(authService, sharePref);

  @injectable
  AuthUseCases get authUseCases => AuthUseCases(
      login: LoginUseCase(authRepository),
      register: RegisterUseCase(authRepository),
      saveUserSession: SaveUserSessionUseCase(authRepository),
      getUserSession: GetUserSessionUseCase(authRepository),
      logout: LogoutUseCase(authRepository));
}
