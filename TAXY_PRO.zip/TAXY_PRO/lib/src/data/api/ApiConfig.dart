class ApiConfig {
  static const String API_TAXYPRO = '192.168.1.13:3000';
}
