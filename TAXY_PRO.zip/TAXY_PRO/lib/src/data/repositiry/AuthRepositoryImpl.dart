import 'dart:convert';
import 'package:taxy_pro/src/data/dataSource/local/SharefPref.dart';
import 'package:taxy_pro/src/data/dataSource/remote/services/AuthService.dart';
import 'package:taxy_pro/src/domain/models/AuthResponse.dart';
import 'package:taxy_pro/src/domain/models/User.dart';
import 'package:taxy_pro/src/domain/repository/AuthRepository.dart';
import 'package:taxy_pro/src/domain/utils/Resource.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthService authService;
  SharePref sharefPref;

  AuthRepositoryImpl(this.authService, this.sharefPref);

  @override
  Future<Resource<AuthResponse>> login(String email, String password) {
    return authService.login(email, password);
  }

  @override
  Future<Resource<AuthResponse>> register(User user) {
    return authService.register(user);
  }

  @override
  Future<AuthResponse?> getUserSession() async {
    final String? jsonSession = await sharefPref.read("user_session");
    if (jsonSession != null) {
      return AuthResponse.fromJson(json.decode(jsonSession));
    }
    return null;
  }

  @override
  Future<void> saveUserSession(AuthResponse authResponse) async {
    final String jsonSession = json.encode(authResponse.toJson());
    await sharefPref.save("user_session", jsonSession);
  }

  @override
  Future<bool> logout() async {
    return await sharefPref.remove('user');
  }
}
