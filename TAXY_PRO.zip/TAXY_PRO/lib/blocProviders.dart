import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/injection.dart';
import 'package:taxy_pro/src/domain/useCases/auth/AuthUseCase.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginBloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterBloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterEvent.dart';
import 'package:taxy_pro/src/presentation/pages/client/home/bloc/ClientHomeBloc.dart';
import 'package:taxy_pro/src/presentation/pages/profile/info/bloc/ProfeleInfoEvent.dart';
import 'package:taxy_pro/src/presentation/pages/profile/info/bloc/ProfileInfoBloc.dart';

List<BlocProvider> blocProviders = [
  BlocProvider<LoginBloc>(
      create: (context) =>
          LoginBloc(locator<AuthUseCases>())..add(LoginInitEvent())),
  BlocProvider<RegisterBloc>(
      create: (context) =>
          RegisterBloc(locator<AuthUseCases>())..add(RegisterInitEvent())),
  BlocProvider<ClientHomeBloc>(
      create: (context) => ClientHomeBloc(locator<AuthUseCases>())),
  BlocProvider<ProfileInfoBloc>(
      create: (context) =>
          ProfileInfoBloc(locator<AuthUseCases>())..add(GetUserInfo())),
];
